![BatteryPass-Ready Logo](https://git.gefeg.com/bp/BatteryPassDataModel/-/raw/f6cf29eff0374aa8b565546238b173691c7a7e2c/Battery%20Pass%20Ready/BatteryPass-Ready_Logo.png)

# BatteryPass-Ready Data Model

> **Work in progress.** This data model and all accompanying documents reference developing legislative and standardisation processes. All resources are subject to change.

## Disclaimer

***Non-mandatory data elements in the schema files should be cross-checked with the requirements in the Data Attribute Longlist v2.0 columns D - H. The new Data Attribute Longlist includes data elements that are "conditional" i.e., only applicable if certain criteria is met. This could not be modelled within the JSON schema files at this moment, resulting in conditionally applicable data elements being represented as non-mandatory, despite being mandatory to batteries meeting certain criteria. An example for this is the element "symbolsForCadmiumAndLead", which mandatorily applies to batteries above the threshold, despite being represented as non-mandatory in the schema files***

***Conditional criteria and exceptions for conditional data elements will be added in another update through plausibility checks***

Elements that are conditional for at least one battery category and thus are still required under certain conditions are:

- symbolsForCadmiumAndLead
- warrantyPeriod
- nickelRecycledContentShare
- cobaltRecycledContentShare
- lithiumRecycledContentShare
- leadRecycledContentShare
- expectedLifetimeNumberofChargeDischargeCycles
- remainingRoundTripEnergyEfficiency
- evolutionOfSelfDischargeRates
- presentInternalResistanceOfPack
- cycleLifeReferenceTest
- cRateOfRelevantCycleLifeTest

**The newest version of the Data Attribute Longlist can be found **[here.](https://thebatterypass.eu/battery-pass-ready/resources/)****

## Overview

This is the official repository for the **BatteryPass-Ready data model** — a structured, machine-readable representation of Battery Passport data requirements aligned with the EU Battery Regulation (EU) 2023/1542.

The model defines the data elements, data types, and codelists required for a compliant Digital Product Passport (DPP) for batteries. It is composed of a base model and five battery-category-specific submodels.

## Repository structure

```
.
├── README.md
├── AdditionalDocuments/
│   ├── Changelog/
│   │   └── changelog.md                                            # Changelog document outlining changes from v1.3 to v2.0
│   ├── v1.3/
│   │   ├── BatteryPass-Ready_data_model_master_documentation.pdf   # Document outlining the JSON-Schema structure by the example of the Battery Passport Master class
│   │   └── BP-Ready_data_model_codelists.pdf                       # Document outlining all codelist values used in JSON Schema files for reference
│   └── v2.0/
│       └── BP-Ready_data_model_codelists_v2.0.pdf
├── JSONSchemaFiles/
│   ├── v1.3/                                                       # JSON Schema files for data validation
│   │   ├── EV.json
│   │   ├── Industrial_Without_BMS.json
│   │   ├── LMT.json
│   │   ├── Other_Industrial_Above_2kWh.json
│   │   └── Stationary_Industrial_Above_2kWh.json
│   └── v2.0/
│       ├── EV_2.0.json
│       ├── EV_Feb_27_2.0.json
│       ├── Industrial_Without_BMS_2.0.json
│       ├── Industrial_Without_BMS_Feb 27_2.0.json
│       ├── LMT_2.0.json
│       ├── LMT_Feb 27_2.0.json
│       ├── Other_Industrial_Above_2kWh_2.0.json
│       ├── Other_Industrial_Above_2kWh_Feb27_2.0.json
│       ├── Stationary_Industrial_Above_2kWh_2.0.json
│       └── Stationary_Industrial_Above_2kWh_Feb27_2.0.json
├── StructureDiagrams/
│   ├── v1.3/                                                       # Interactive HTML structure diagrams
│   │   ├── EV/
│   │   │   └── EV_standalone.html
│   │   ├── Industrial_without_BMS/
│   │   │   └── Industrial_without_BMS_standalone.html
│   │   ├── LMT/
│   │   │   └── LMT_standalone.html
│   │   ├── Other_Industrial_above_2kWh/
│   │   │   └── Other_Industrial_standalone.html
│   │   └── Stationary_Industrial_above_2kWh/
│   │       └── Stationary_Industrial_standalone.html
│   └── v2.0/
│       ├── EV/
│       │   ├── EV_Feb27_standalone.html
│       │   └── EV_standalone.html
│       ├── Industrial_Without_BMS/
│       │   ├── Industrial_Without_BMS_Feb27_standalone.html
│       │   └── Industrial_Without_BMS_standalone.html
│       ├── LMT/
│       │   ├── LMT_Feb27_standalone.html
│       │   └── LMT_standalone.html
│       ├── Other_Industrial_above_2kWh/
│       │   ├── Other_Industrial_Above_2kWh_Feb27_standalone.html
│       │   └── Other_Industrial_Above_2kWh_standalone.html
│       └── Stationary_Industrial_above_2kWh/
│           ├── Stationary_Industrial_Above_2kWh_Feb27_standalone.html
│           └── Stationary_Industrial_Above_2kWh_standalone.html
├── XSDFiles/
│   ├── v1.3/                                                       # XML Schema files for data validation
│   │   ├── EV.XSD/
│   │   │   ├── EV.xsd
│   │   │   └── EV_Datatypes.xsd
│   │   ├── Industrial_Without_BMS.XSD/
│   │   │   ├── Industrial_Without_BMS.xsd
│   │   │   └── Industrial_Without_BMS_Datatypes.xsd
│   │   ├── LMT.XSD/
│   │   │   ├── LMT.xsd
│   │   │   └── LMT_Datatypes.xsd
│   │   ├── Other_Industrial_2kWh.XSD/
│   │   │   ├── Other_Industrial_2kWh.xsd
│   │   │   └── Other_Industrial_2kWh_Datatypes.xsd
│   │   └── Stationary_Industrial_2kWh.XSD/
│   │       ├── Stationary_Industrial_2kWh.xsd
│   │       └── Stationary_Industrial_2kWh_Datatypes.xsd
│   └── v2.0/                                                       # One folder per battery category and per requirement date
│       ├── EV.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── EV.xsd
│       ├── EV_Feb27.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── EV_Feb27.xsd
│       ├── Industrial_Without_BMS.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── Industrial_Without_BMS.xsd
│       ├── Industrial_Without_BMS_Feb27.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── Industrial_Without_BMS_Feb27.xsd
│       ├── LMT.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── LMT.xsd
│       ├── LMT_Feb27.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── LMT_Feb27.xsd
│       ├── Other_Industrial_2kWh.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── Other_Industrial_2kWh.xsd
│       ├── Other_Industrial_2kWh_Feb27.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── Other_Industrial _2kWh_Feb27.xsd
│       ├── Stationary_Industrial_2kWh.XSD/
│       │   ├── Datatypes.xsd
│       │   ├── DPP_Header.xsd
│       │   └── Stationary_Industrial_2kWh.xsd
│       └── Stationary_Industrial_2kWh_Feb27.XSD/
│           ├── Datatypes.xsd
│           ├── DPP_Header.xsd
│           └── Stationary_Industrial_2kWh_Feb27.xsd
└── BatteryPass-Ready_Logo.png
```

## Contents

### Additional documents

The codelist document (`AdditionalDocuments/BP-Ready_data_model_codelists.pdf`) is the reference for all coded data types used in the model. It describes permissible values for each coded attribute across all battery categories.

The data model master documentation document (`AdditionalDocuments/BatteryPass-Ready_data_model_master_documentation.pdf`) is the reference for data model structure and information about data types for version 1.3, as well as information about related work.

For information about version 2.0, please refer to the technical references within the BatteryPass-Ready Data Attribute Longlist v2.0. You can find the document **[here.](https://thebatterypass.eu/battery-pass-ready/resources/)**

For the detailed changelog between v1.3 and v2.0 please refer to the changelog file (`AdditionalDocuments/changelog.md`)

### JSON Schemas

The `JSON Data/JSON Schemas/` folder contains two JSON Schemas per battery category. These schemas are used for data validation in the BatteryPass-Ready test environment and conform to [JSON Schema Draft 2020-12](https://json-schema.org/draft/2020-12).

| File | Battery category |
|------|-----------------|
| `EV_Feb27.json` | Electric vehicle batteries reflecting requirements for February 2027|
| `EV.json` | Electric vehicle batteries reflecting all requirements|
| `Industrial_Without_BMS_Feb27.json` | Industrial batteries without a Battery Management System reflecting requirements for February 2027|
| `Industrial_Without_BMS.json` | Industrial batteries without a Battery Management System reflecting general requirements|
| `LMT.json_Feb27` | Light means of transport batteries reflecting requirements for February 2027|
| `LMT.json` | Light means of transport batteries reflecting general requirements|
| `Other_Industrial_Above_2kWh_Feb27.json` | Other industrial batteries with capacity above 2 kWh reflecting requirements for February 20207|
| `Other_Industrial_Above_2kWh.json` | Other industrial batteries with capacity above 2 kWh relfecting general requirements|
| `Stationary_Industrial_Above 2kWh_Feb27.json` | Stationary industrial batteries with capacity above 2 kWh reflecting requirements for February 2027|
| `Stationary_Industrial_Above 2kWh.json` | Stationary industrial batteries with capacity above 2 kWh reflecting general requirements|

### Structure diagrams

The `JSON Data/JSON Structure Diagrams/` folder contains one HTML file per battery category. Open the HTML file in a browser to explore the full hierarchical structure of that category's data model interactively.

## Data model structure

Each submodel (battery category schema file) follows the structure of the base model. The base model defines the **Battery Passport Master** class — a blueprint for all battery category submodels. This class is described within the data model master documentation for v1.3.(`AdditionalDocuments/BatteryPass-Ready_data_model_master_documentation.pdf`). For other versions, this class is continuously used.

### Top-level data element groups

| Group | Description |
|-------|-------------|
| Symbols, Labels and Documentation of Conformity | Conformity markings, labels, and declarations |
| Supply Chain Due Diligence | Due diligence reports and third-party assurances |
| Performance and Durability | Capacity, power, efficiency, and lifecycle metrics |
| Identifiers and Product Data | Passport identifiers, manufacturer data, and product metadata |
| Circularity and Resource Efficiency | Recycled content, dismantling information, end-of-life guidance |
| Battery Materials and Composition | Chemistry, critical raw materials, hazardous substances |
| Battery Carbon Footprint | Lifecycle carbon footprint data and performance class |

### Terminology

- **Data element** — the lowest-level instance of Battery Passport data (e.g., *Capacity fade*)
- **Data element group** — a named group of related data elements (e.g., *Performance and Durability*)
- **Battery Passport Master** — a blueprint class used to unify base-level classes via inheritance
- **Battery Passport** — the class representing an actual battery passport instance
- **Battery Passport data** — the container class, modified per submodel, that holds category-specific data requirements

No mandatory data requirements are set at the master level. All requirements are specified at the submodel level for each respective battery category.

## Regulatory context

The BatteryPass-Ready data model is designed to support compliance with:

- **EU Battery Regulation (EU) 2023/1542** — establishing requirements for batteries and waste batteries (including available delegated and implementing (draft) acts)
- **JTC-24 Digital Product Passport standardization** - standardized technical requirements for DPPs

## Additional resources

BatteryPass-Ready also maintains the Data Attribute Longlist. This document provides a comprehensive (non-technical) overview of battery passport data elements, their definitions and understanding per BatteryPass-Ready consortium, data element granularity level and regulatory references. The Data Attribute Longlist also provides the base for the BatteryPass-Ready data model. **Please note: Due to ongoing regulatory developments, the Data Attribute Longlist is also subject to change.** You can find the current version of the document **[here.](https://thebatterypass.eu/battery-pass-ready/resources/)**

## Copyright

Copyright © 2026 BatteryPass-Ready Consortium. This document is made available under a CC BY Licence (Attribution). For more Information see: https://creativecommons.org/licenses/by/4.0.

The resources in this repository are maintained by acatech on behalf of the BatteryPass-Ready Consortium.

## Version

Current version: **2.0** (work in progress)